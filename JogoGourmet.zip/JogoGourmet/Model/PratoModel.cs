﻿namespace JogoGourmet.Model
{
    public class PratoModel
    {
        #region :: properties ::

        /// <summary>
        /// Propriedade que corresponde ao nome do prato.
        /// Esta propriedade só pode ser atribuída mediante construtor da classe.
        /// </summary>
        public string Nome { get; private set; }
        /// <summary>
        /// Propriedade que corresponde à característica do prato.
        /// </summary>
        public string Caracteristica { get; set; }

        #endregion

        #region :: constructors ::

        #region :: private ::

        /// <summary>
        /// Construtor inibido para que seja utilizado.
        /// </summary>
        private PratoModel()
        {
        }

        #endregion

        #region :: public ::
        
        /// <summary>
        /// Construtor a ser utilizado quando não há necessidade de se criar um prato com característica.
        /// </summary>
        /// <param name="nome">Nome do prato a ser criado na instância.</param>
        public PratoModel(string nome)
        {
            Nome = nome;
        }
        /// <summary>
        /// Construtor a ser utilizado quando se deseja criar um prato com nome e sua respectiva característica.
        /// </summary>
        /// <param name="nome">Nome do prato a ser criado na instância.</param>
        /// <param name="caracteristica">Característica do prato a ser criado na instância.</param>
        public PratoModel(string nome, string caracteristica)
        {
            Nome = nome;
            Caracteristica = caracteristica;
        }

        #endregion

        #endregion
    }
}