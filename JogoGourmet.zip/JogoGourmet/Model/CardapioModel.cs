﻿using System.Collections.Generic;

namespace JogoGourmet.Model
{
    public class CardapioModel
    {
        #region :: properties ::

        /// <summary>
        /// Propriedade corresponde à lista de pratos que irão compor o cardápio.
        /// </summary>
        public List<PratoModel> Pratos { get; set; }

        #endregion

        #region :: constructors ::

        public CardapioModel() 
        {
            Pratos = new List<PratoModel>();
        }

        #endregion
    }
}