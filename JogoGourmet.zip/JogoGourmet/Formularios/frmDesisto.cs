﻿using JogoGourmet.Enumeradores;
using JogoGourmet.Model;
using System;
using System.Windows.Forms;

namespace JogoGourmet
{
    public partial class frmDesisto : Form
    {
        #region :: attributes ::

        // Instância a ser vinculada ao formulário principal para manipulação.
        frmPrincipal _frmPrincipal;

        #endregion

        #region :: constructors ::

        #region :: private ::

        /// <summary>
        /// Construtor inibido para que seja utilizado.
        /// </summary>
        private frmDesisto()
        {
        }

        #endregion

        #region :: public ::

        /// <summary>
        /// Construtor a ser utilizado pela classe.
        /// </summary>
        /// <param name="formularioPrincipal">Instância do formulário principal, para que possa ser acessado e manipulado dentro dessa classe.</param>
        public frmDesisto(frmPrincipal formularioPrincipal)
        {
            InitializeComponent();

            // Vincula a instância do formulário principal 
            // para que possa ser acessado e manipulado.
            _frmPrincipal = formularioPrincipal;
        }

        #endregion

        #endregion

        #region :: events ::

        #region :: form ::
        
        private void frmDesisto_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Desbloqueia o form principal para um novo fluxo.
            _frmPrincipal.HabilitarNovoFluxo();
        }

        #endregion

        #region :: button ::

        private void btnOk_Click(object sender, EventArgs e)
        {
            // Certifica que o nome do prato foi informado...
            if (!string.IsNullOrEmpty(txtNome.Text))
            {
                // Atribui o nome do novo prato à lista pertinente.
                switch (_frmPrincipal.TipoCardapio)
                {
                    default: break;
                    case TiposCardapio.Massa: _frmPrincipal.CardapioMassas.Pratos.Add(new PratoModel(txtNome.Text)); break;
                    case TiposCardapio.Customizado: _frmPrincipal.CardapioCustomizado.Pratos.Add(new PratoModel(txtNome.Text)); break;
                }
                
                // Exibe o formulário de cadastro complementar.
                new frmComplete(_frmPrincipal).Show();

                Close();
            }
            else
            {
                // Alerta o jogador quanto ao preenchimento do nome do prato.
                MessageBox.Show("Informe o prato que pensou!", "Validação", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void btnCancelar_Click(object sender, EventArgs e)
        {
            // Desbloqueia o form principal para um novo fluxo.
            _frmPrincipal.HabilitarNovoFluxo();

            Close();
        }

        #endregion

        #endregion
    }
}