﻿using JogoGourmet.Enumeradores;
using JogoGourmet.Model;
using System;
using System.Linq;
using System.Windows.Forms;

namespace JogoGourmet
{
    public partial class frmPrincipal : Form
    {
        #region :: attributes ::

        bool _indicadorPrimeiroSucesso = true;

        #endregion

        #region :: properties ::

        #region :: bool ::

        /// <summary>
        /// Propriedade que indica se o fluxo de perguntas permitiu descobrir 
        /// ao menos a característica do novo prato a ser atribuído ao cardápio.
        /// </summary>
        public bool IndicadorMesmaCaracteristica { get; set; }

        #endregion

        #region :: enum ::
        
        /// <summary>
        /// Propriedade que indica o tipo de cardápio considerado no fluxo corrente do jogo.
        /// </summary>
        public TiposCardapio TipoCardapio { get; set; }

        #endregion

        #region :: model ::
        
        /// <summary>
        /// Propriedade que armazena a lista de pratos coletados do jogador nos fluxos de cardápio do tipo "Massa".
        /// </summary>
        public CardapioModel CardapioMassas { get; set; }
        /// <summary>
        /// /// Propriedade que armazena a lista de pratos coletados do jogador nos fluxos de cardápio do tipo "Customizado".
        /// </summary>
        public CardapioModel CardapioCustomizado { get; set; }

        #endregion

        #endregion

        #region :: constructors ::

        /// <summary>
        /// Construtor padrão da classe.
        /// </summary>
        public frmPrincipal()
        {
            InitializeComponent();

            // Gera os dados iniciais do jogo.
            MontarCardapioInicial();
        }

        #endregion

        #region :: methods ::

        #region :: private ::
        
        #region :: void ::

        /// <summary>
        /// Método que exibe a mensagem de sucesso do jogo de forma centralizada.
        /// </summary>
        private void ExibirMensagemSucesso()
        {
            string mensagem = (_indicadorPrimeiroSucesso) ? "Acertei!" : "Acertei de novo!";

            MessageBox.Show(mensagem, "Jogo Gourmet", MessageBoxButtons.OK, MessageBoxIcon.Information);

            _indicadorPrimeiroSucesso = false;
        }
        /// <summary>
        /// Método que prepara o jogo gerando os dados iniciais.
        /// </summary>
        private void MontarCardapioInicial()
        {
            CardapioMassas = new CardapioModel();
            CardapioCustomizado = new CardapioModel();

            // Cria os pratos iniciais de cada cardápio.
            CardapioMassas.Pratos.Add(new PratoModel("Lasanha", "massa"));
            CardapioCustomizado.Pratos.Add(new PratoModel("Bolo de Chocolate", "bolo"));
        }
        /// <summary>
        /// Métod que controla o fluxo de perguntas do jogo, direcionadas ao jogador.
        /// </summary>
        /// <param name="indiceLimite">Índice que corresponde à posição do prato no cardápio.</param>
        private void ExecutarPerguntas(int indiceLimite)
        {      
            // Percorre a a lista de pratos pertinente ao cardápio pertinente.
            for (int indice = 0; indice < indiceLimite; indice++)
            {
                string pergunta = "O prato que você pensou é";

                // Apenas para facilitar a leitura...
                bool indicadorPenultimoIndice = indice.Equals(indiceLimite - 1);

                if (!IndicadorMesmaCaracteristica)
                {
                    // Monta a pergunta que deverá ser feita ao jogador.
                    pergunta = string.Format("{0} {1}?", pergunta, (indicadorPenultimoIndice) ? ObterProximoNome(0) : ObterProximaCaracteristica(indice + 1));
                }
                else
                {
                    // Monta a pergunta que deverá ser feita ao jogador.
                    pergunta = string.Format("{0} {1}?", pergunta, (indicadorPenultimoIndice) ? ObterProximoNome(indice) : ObterProximaCaracteristica(indice + 1));
                }

                // Exibe a pergunta ao jogador e obtém a opção dele.
                DialogResult respostaJogador = ObterRespostaJogador(pergunta);

                if (respostaJogador.Equals(DialogResult.Yes))
                {
                    IndicadorMesmaCaracteristica = true;

                    if (indicadorPenultimoIndice)
                    {
                        // Finaliza o fluxo exibindo uma mensagem.
                        ExibirMensagemSucesso();

                        // Reabilita o formulário para um novo fluxo.
                        HabilitarNovoFluxo();
                    }
                }
                else
                {
                    IndicadorMesmaCaracteristica = false;

                    if (indicadorPenultimoIndice)
                    {
                        // Exibe o formulário de cadastro de prato.
                        new frmDesisto(this).Show();

                        return;
                    }
                }
            }
        }

        #endregion

        #region :: string ::

        /// <summary>
        /// Método que retorna o nome do prato pertinente ao índice de cardápio informado.
        /// </summary>
        /// <param name="indice">Índice pertinente ao prato a ser obtido, no cardápio.</param>
        /// <returns>Nome do prato pertinente ao índice de cardápio informado.</returns>
        private string ObterProximoNome(int indice)
        {
            switch (TipoCardapio)
            {
                default:
                case TiposCardapio.Massa: return CardapioMassas.Pratos[indice].Nome;
                case TiposCardapio.Customizado: return CardapioCustomizado.Pratos[indice].Nome;                
            }            
        }
        /// <summary>
        /// Método que retorna a característica do prato pertinente ao índice de cardápio informado.
        /// </summary>
        /// <param name="indice">Índice pertinente à característica a ser obtida, no cardápio.</param>
        /// <returns>Característica do prato pertinente ao índice de cardápio informado.</returns>
        private string ObterProximaCaracteristica(int indice)
        {
            switch (TipoCardapio)
            {
                default:
                case TiposCardapio.Massa: return CardapioMassas.Pratos[indice].Caracteristica;
                case TiposCardapio.Customizado: return CardapioCustomizado.Pratos[indice].Caracteristica;
            }
        }

        #endregion

        #region :: DialogResult ::

        /// <summary>
        /// Método que exibe uma pergunta ao jogador de forma centralizada e obtém sua resposta.
        /// </summary>
        /// <param name="pergunta">Pergunta a ser feita ao jogador.</param>
        /// <returns>Opção escolhida pelo jogador.</returns>
        private DialogResult ObterRespostaJogador(string pergunta)
        {
            return MessageBox.Show(pergunta, "Confirme", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
        }

        #endregion

        #endregion

        #region :: public ::

        #region :: void ::

        /// <summary>
        /// Método que previne que um novo fluxo de jogo seja iniciado antes que o fluxo corrente esteja finalizado.
        /// </summary>
        public void BloquearNovoFluxo()
        {
            btnOk.Enabled = false;
        }
        /// <summary>
        /// Método que reabilita um novo fluxo de jogo.
        /// </summary>
        public void HabilitarNovoFluxo()
        {
            btnOk.Enabled = true;
        }
        /// <summary>
        /// Método que remove o prato, cujo cadastro já estava em andamento.
        /// </summary>
        public void RemoverInclusaoPendente()
        {
            PratoModel prato;

            // Atribui o nome do novo prato à lista pertinente.
            switch (TipoCardapio)
            {
                case TiposCardapio.Massa:

                    // Localiza o prato que estava sendo cadastrado no cardápio de massas...
                    prato = CardapioMassas.Pratos.Where(item => string.IsNullOrEmpty(item.Caracteristica)).FirstOrDefault();

                    // ... e se o encontrar
                    if (prato != null)
                    {
                        // remove!
                        CardapioMassas.Pratos.Remove(prato);
                    }

                    break;

                case TiposCardapio.Customizado:

                    // Localiza o prato que estava sendo cadastrado no cardápio de massas...
                    prato = CardapioCustomizado.Pratos.Where(item => string.IsNullOrEmpty(item.Caracteristica)).FirstOrDefault();

                    // ... e o encontrar
                    if (prato != null)
                    {
                        // remove!
                        CardapioCustomizado.Pratos.Remove(prato);
                    }

                    break;

                default: break;
            }
        }

        #endregion

        #endregion

        #endregion

        #region :: events ::

        private void btnOk_Click(object sender, EventArgs e)
        {
            TipoCardapio = TiposCardapio.NaoInformado;

            // Garante um fluxo completo.
            BloquearNovoFluxo();

            while (true)
            {
                // Efetua a primeira pergunta ao jogador, que irá definir o tipo de cardápio a ser considerado neste fluxo de perguntas.
                DialogResult respostaJogador = ObterRespostaJogador(string.Format("O prato que você pensou é {0}?", ObterProximaCaracteristica(0)));

                // Obtém o tipo de cardápio a ser considerado no fluxo corrente do jogo.
                TipoCardapio = (respostaJogador.Equals(DialogResult.Yes)) ? TiposCardapio.Massa : TiposCardapio.Customizado;

                // Inicia um fluxo de perguntas utilizando 
                // o cardápio pertinente ao tipo considerado.
                if (TipoCardapio.Equals(TiposCardapio.Massa))
                {
                    ExecutarPerguntas(CardapioMassas.Pratos.Count);
                }
                else
                {
                    ExecutarPerguntas(CardapioCustomizado.Pratos.Count);
                }

                return;
            }
        }

        #endregion
    }
}