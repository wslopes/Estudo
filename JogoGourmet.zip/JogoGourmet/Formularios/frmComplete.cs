﻿using JogoGourmet.Enumeradores;
using JogoGourmet.Model;
using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace JogoGourmet
{
    public partial class frmComplete : Form
    {
        #region :: attributes ::

        #region :: form ::

        // Instância a ser vinculada ao formulário principal para manipulação.
        frmPrincipal _frmPrincipal;

        #endregion

        #region :: string ::

        // Nome do último prato a ser exibido na pergunta dinâmica do formulário.
        string _ultimoPrato = string.Empty;
        // Nome do prato de referência a ser exibido na pergunta dinâmica do formulário.
        string _pratoComparado = string.Empty;

        #endregion

        #endregion

        #region :: constructors ::

        #region :: private ::

        /// <summary>
        /// Construtor inibido para que seja utilizado.
        /// </summary>
        private frmComplete()
        {
        }

        #endregion

        #region :: public ::
        
        /// <summary>
        /// Construtor a ser utilizado pela classe.
        /// </summary>
        /// <param name="formularioPrincipal">Instância do formulário principal, para que possa ser acessado e manipulado dentro dessa classe.</param>
        public frmComplete(frmPrincipal formularioPrincipal)
        {
            InitializeComponent();

            // Vincula a instância do formulário principal 
            // para que possa ser acwssado e manipulado.
            _frmPrincipal = formularioPrincipal;

            int indiceUltimoPrato = 0;
            int indicePratoComparado = (!_frmPrincipal.IndicadorMesmaCaracteristica) ? indiceUltimoPrato : 0;

            switch (_frmPrincipal.TipoCardapio)
            {               
                case TiposCardapio.Massa:

                    // Apenas para facilitar a leitura...
                    indiceUltimoPrato = _frmPrincipal.CardapioMassas.Pratos.Count - 1;

                    // Obtém dinamicamente o nome dos pratos a serem exibidos.
                    _ultimoPrato = _frmPrincipal.CardapioMassas.Pratos[indiceUltimoPrato].Nome;
                    _pratoComparado = _frmPrincipal.CardapioMassas.Pratos[indicePratoComparado].Nome;                    
                    break;

                case TiposCardapio.Customizado:

                    // Apenas para facilitar a leitura...
                    indiceUltimoPrato = _frmPrincipal.CardapioCustomizado.Pratos.Count - 1;

                    // Obtém dinamicamente o nome dos pratos a serem exibidos.
                    _ultimoPrato = _frmPrincipal.CardapioCustomizado.Pratos[indiceUltimoPrato].Nome;
                    _pratoComparado = _frmPrincipal.CardapioCustomizado.Pratos[indicePratoComparado].Nome;
                    break;

                default: break;
            }

            // Monta o texto dinâmico a ser exibido ao jogador.
            lblPerguntaDinamica.Text = string.Format("{0} é ______ mas {1} não.", _ultimoPrato, _pratoComparado);
        }

        #endregion

        #endregion

        #region :: methods ::

        /// <summary>
        /// Método que trata o cancelamento de inclusão de complemento.
        /// Caso haja alguma inclusão pendente, descarta e na sequência, 
        /// reabilita o formulário principal para o início de um novo fluxo.
        /// </summary>
        private void VerificarPendencias()
        {
            // Remove o prato que acabou de ser incluído.
            _frmPrincipal.RemoverInclusaoPendente();

            // Desbloqueia o form principal para um novo fluxo.
            _frmPrincipal.HabilitarNovoFluxo();
        }

        #endregion

        #region :: events ::

        #region :: form ::

        private void frmComplete_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Verifica se ainda existe algo no 
            // fluxo que precisa ser tratado.
            VerificarPendencias();
        }

        #endregion
        
        #region :: button ::
        
        private void btnOk_Click(object sender, EventArgs e)
        {
            // Certifica que a característica foi informada...
            if (!string.IsNullOrEmpty(txtCaracteristica.Text))
            {
                PratoModel prato = null;

                // Obtém a instância do novo
                // prato na lista pertinente.
                switch (_frmPrincipal.TipoCardapio)
                {                    
                    case TiposCardapio.Massa: 
                        
                        prato = _frmPrincipal.CardapioMassas.Pratos.Where(item => item.Nome.Equals(_ultimoPrato)).FirstOrDefault(); 
                        break;

                    case TiposCardapio.Customizado: 
                        
                        prato = _frmPrincipal.CardapioCustomizado.Pratos.Where(item => item.Nome.Equals(_ultimoPrato)).FirstOrDefault(); 
                        break;

                    default: break;
                }

                if (prato != null)
                {
                    // Atribui a caracteristica informada ao novo prato.
                    prato.Caracteristica = txtCaracteristica.Text;

                    // Desbloqueia o form principal para um novo fluxo.
                    _frmPrincipal.HabilitarNovoFluxo();

                    Close();
                }
            }
            else
            {
                // Alerta o jogador quanto ao preenchimento da característica.
                MessageBox.Show("Responda a pergunta!", "Validação", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Close();
        }

        #endregion

        #endregion
    }
}