﻿namespace JogoGourmet.Enumeradores
{
    /// <summary>
    /// Enum que corresponde aos tipos de cardápios reconhecidos pelo jogo.
    /// </summary>
    public enum TiposCardapio
    {
        Massa,
        Customizado,
        NaoInformado
    }
}